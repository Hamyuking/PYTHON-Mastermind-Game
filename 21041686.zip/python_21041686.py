#Python native packages: random module
import random

#List: contains the six possibe colours 
cList = ['B', 'G', 'O', 'P', 'R', 'Y']

#Randomization: generate random choice from a list
def generate_colour():
    code = [random.choice(cList), random.choice(cList), random.choice(cList),random.choice(cList)]
    return code

#Checking Process: input validation, correct colour code
def user_input(code):
    pickcode = [] #List: empty list to store user input
    print ()
    #Validation check: user can only enter valid inputs
    while len(pickcode)!=4: #Loop: ask four choices of colours from user
        pick = str(input("Enter 4 colours in sequence [B/G/O/P/R/Y]: ")).upper() #convert user input to the same case
        if pick in cList: 
            pickcode.append(pick) #List: add only the valid user input 
        else:
            print ("Invalid colour. Please enter again.") #invalid input is not counted as a guess
    print ("-"*70)
    print ("The colour code that you have picked is", pickcode)
    print ("-"*70)
    #Variable initialization: set to zero for incremental counting
    correct = 0
    wrong_place = 0
    #If statement: compare the first user input with randomized code
    if code[0] == pickcode[0]:
        correct += 1 
    elif code[0] == pickcode[1] or code[0] == pickcode[2] or code[0] == pickcode[3]:
        wrong_place += 1
    #compare the second colour
    if code[1] == pickcode[1]:
        correct += 1
    elif code[1] == pickcode[0] or code[1] == pickcode[2] or code[1] == pickcode[3]:
        wrong_place += 1
    #compare the third colour
    if code[2] == pickcode[2]:
        correct += 1 
    elif code[2] == pickcode[0] or code[2] == pickcode[1] or code[2] == pickcode[3]:
        wrong_place += 1
    #compare the fourth colour
    if code[3] == pickcode[3]:
        correct += 1 
    elif code[3] == pickcode[0] or code[3] == pickcode[1] or code[3] == pickcode[2]:
        wrong_place += 1
    #Display checking result as a hint for user 
    print ("Correct colour in the correct place: ", correct)
    print ("Correct colours but in the wrong place: ", wrong_place)
    result = [correct, wrong_place] 
    return result 

#Gameplay: the start of Master Mind game
def game_start():
    code = generate_colour()
    print (code)
    #Variable initialization: set to zero for incremental counting
    attempt = 0
    game = True 
    while game: #loop: iterative process until user correctly enter four colours in order
        (correct, wrong_place) = user_input(code)
        attempt +=1 #every guess is counted
        if correct == 4:#condition to exit loop
            game = False 
        else:
            print ("Let's guess it again......")
            game = True
    print("Congrats! You took", attempt ,"guesses to guess the correct colours in order." )
    print()


#Graphical interface: display title and instruction in text file        
I = open('Instruction.txt','r')
I_content = I.read()
print (I_content)


start = 'Y'
while start: #loop: create interactive menu
    start = str(input("Are you ready to play againts the computer? [Y/N]: ")).upper()
    if start == 'Y':
        game_start()
        restart = 'Y'
        while restart:
            restart = str(input("Do you wish to restart the game? [Y/N]: ")).upper()
            if restart == 'Y':
                print()
                print ("-"*40, "Next Round", "-"*56)
                print()
                break
            elif restart == 'N':
                start = False
                break #exit loop if the user is not ready
            else:
                print("Please type only a Yes or No......")
    elif start == 'N':
        break #exit loop if the user is not ready
    else:
        print("Please type only a Yes or No.......")   
print()
print ("="*40, "Game Over", "="*56)






